An Api for adding Custom Phone Messages, Contacts and Notifications
Used in Sicklines

git: https://github.com/arikidev/EmailApi